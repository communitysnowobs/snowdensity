function [SWE] = swe_calculator(Y,M,D,H,LAT,LON,CODE)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function implements a power law regression in order to produce a
%value of snow water equivalent (SWE) based on various parameters
%associated with a snow depth measurement. The input variables can be
%scalars (single measurement) or vectors (batch measurements). The
%following information on units, etc., is critical.

%David Hill, Oregon State University
%October 2018

%SWE (output) - snow water equivalent (mm)
%H - snow depth (mm)
%Y - year
%M - month (1 --> 12)
%D - day (1 --> 31 (or 28, or 30, as appropriate))
%LAT - latitude. Positive for N. Hem.
%LON - longitude (signed). So, -120 or so for North America.
%CODE - 1 for CONUS, 2 for Alaska, 3 for British Columbia
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Do CONUS points first
I=find(CODE==1);
if length(I)>0
    [febtmean.conus,Rconus]=arcgridread('PRISM_data/CONUS/PRISM_tmean_30yr_normal_800mM2_02_asc.asc');
    [precip.conus,Rconus]=arcgridread('PRISM_data/CONUS/PRISM_ppt_30yr_normal_800mM2_annual_asc.asc');
    %Next, we need to do some things related to the reference matrices. The
    %ones for Alaska and BC come in as a GeographicCellsReference. I have no idea why
    %this one is different than the others. The R for CONUS and 
    %comes in as a simple ref marix. So, for interpolation purposes, I will
    %now convert the ref matrix to a MapCellsReference. I have not fully figured
    %out how to go back and forth between the Geo and Map versions. But, I can
    %make do...
    Rconus_map=refmatToMapRasterReference(Rconus,size(febtmean.conus));    
    FEBTMEAN(I)=mapinterp(febtmean.conus,Rconus_map,LON(I),LAT(I));
    MAP(I)=mapinterp(precip.conus,Rconus_map,LON(I),LAT(I));
end

%Do AK points next
I=find(CODE==2);
if length(I)>0
    [febtmean.alaska,Ralaska]=arcgridread('PRISM_data/AK/PRISM_tmean_30yr_normal_02_alaska.asc');
    febtmean.alaska=febtmean.alaska/100; %to put into mm.
    [precip.alaska,Ralaska]=arcgridread('PRISM_data/AK/PRISM_ppt_30yr_normal_annual_alaska.asc');
    precip.alaska=precip.alaska/100; %to put into mm.   
    FEBTMEAN(I)=geointerp(febtmean.alaska,Ralaska,LAT(I),LON(I));
    MAP(I)=geointerp(precip.alaska,Ralaska,LAT(I),LON(I));
end

%Do BC points last
I=find(CODE==3);
if length(I)>0
    [febtmean.bc,Rbc]=arcgridread('PRISM_data/BC/PRISM_tmean_30yr_normal_02_bc.asc');
    febtmean.bc=febtmean.bc/10; %to put into mm
    [precip.bc,Rbc]=arcgridread('PRISM_data/BC/PRISM_ppt_30yr_normal_annual_bc.asc');
    FEBTMEAN(I)=geointerp(febtmean.bc,Rbc,LAT(I),LON(I));
    MAP(I)=geointerp(precip.bc,Rbc,LAT(I),LON(I));
end

%Next, we need to turn our year / month / day information into a 'day of
%water year' (DOY)

DOY=datenum(Y,M,D)-datenum(Y,9,30); %OCT 1 will have a DOY of 1
DOY(DOY<0)=DOY(DOY<0)+365; %make all values positive, in range of 1 --> 365

%finally, we apply the regression equation. First define the regression
%coefficients.

a=[-1.8946 1.070 0.132 0.506];   %accumulation phase
b=[-1.5707 1.038 0.201 0.310];   %ablation phase

SWE=10^a(1)*H.^a(2).*MAP.^a(3).*(FEBTMEAN+30).^a(4).* ...
    (-tanh(0.01*(DOY-180))+1)/2 + 10^b(1)*H.^b(2).*MAP.^b(3).* ...
    (FEBTMEAN+30).^b(4).*(tanh(0.01*(DOY-180))+1)/2;
end

