British Columbia PRISM Data

See the link at: http://cfcg.forestry.ubc.ca/projects/climate-data/climatebcwna/

Normals for 1981-2010

PRISM_VERSION: unknown

spatial res 0.008333 degrees
NAD 1983
GRS 80

temp files are in degrees C 
ppt files are in mm 

