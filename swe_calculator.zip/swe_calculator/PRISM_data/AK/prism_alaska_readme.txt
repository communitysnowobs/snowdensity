Alaska PRISM Data

See the link at: http://www.prism.oregonstate.edu/normals/special_projects.php

Normals for 1971-2000

PRISM_VERSION: unknown

spatial res 0.012608090165 degrees
NAD 1983
GRS 80

temp files are in degrees C * 100
ppt files are in mm * 100

