CONUS PRISM Data

http://www.prism.oregonstate.edu/

Normals for 1981-2010

PRISM_VERSION: 14.1-20140502-1000

spatial res 0.00833333 degrees
NAD 1983
GRS 80

temp files are in degrees C
ppt files are in mm

